package kr.co.dadrip.sample;


import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Chef {

}
