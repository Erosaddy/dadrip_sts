package kr.co.dadrip.domain;

import lombok.Data;

@Data
public class FavoriteDTO {
	
	private int favorite_id;
	private int joke_id;
	private String member_id;
	
}
